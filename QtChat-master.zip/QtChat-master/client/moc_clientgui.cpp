/****************************************************************************
** Meta object code from reading C++ file 'clientgui.h'
**
** Created: Fri Dec 6 16:57:19 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "clientgui.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'clientgui.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_clientGUI[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: signature, parameters, type, tag, flags
      24,   11,   10,   10, 0x05,
      65,   61,   10,   10, 0x05,
      82,   10,   10,   10, 0x05,
     102,   95,   10,   10, 0x05,
     124,   10,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
     140,   10,   10,   10, 0x0a,
     164,  155,   10,   10, 0x0a,
     196,  192,   10,   10, 0x0a,
     231,   10,   10,   10, 0x0a,
     258,  252,   10,   10, 0x0a,
     278,   10,   10,   10, 0x08,
     300,   10,   10,   10, 0x08,
     319,   10,   10,   10, 0x08,
     338,   10,   10,   10, 0x08,
     360,   10,   10,   10, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_clientGUI[] = {
    "clientGUI\0\0ip,port,user\0"
    "sendConnectInfo(QString,int,QString)\0"
    "msg\0sendMsg(QString)\0quitClient()\0"
    "status\0updateStatus(QString)\0"
    "chatPageBuilt()\0wasConnected()\0user,msg\0"
    "gotMessage(QString,QString)\0map\0"
    "updateList(QMap<QString,QString>&)\0"
    "onServerDisconnect()\0error\0"
    "catchError(QString)\0connectButtonPushed()\0"
    "sendButtonPushed()\0quitButtonPushed()\0"
    "enableConnectButton()\0enableSendButton()\0"
};

void clientGUI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        clientGUI *_t = static_cast<clientGUI *>(_o);
        switch (_id) {
        case 0: _t->sendConnectInfo((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 1: _t->sendMsg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->quitClient(); break;
        case 3: _t->updateStatus((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->chatPageBuilt(); break;
        case 5: _t->wasConnected(); break;
        case 6: _t->gotMessage((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 7: _t->updateList((*reinterpret_cast< QMap<QString,QString>(*)>(_a[1]))); break;
        case 8: _t->onServerDisconnect(); break;
        case 9: _t->catchError((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 10: _t->connectButtonPushed(); break;
        case 11: _t->sendButtonPushed(); break;
        case 12: _t->quitButtonPushed(); break;
        case 13: _t->enableConnectButton(); break;
        case 14: _t->enableSendButton(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData clientGUI::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject clientGUI::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_clientGUI,
      qt_meta_data_clientGUI, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &clientGUI::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *clientGUI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *clientGUI::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_clientGUI))
        return static_cast<void*>(const_cast< clientGUI*>(this));
    return QDialog::qt_metacast(_clname);
}

int clientGUI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void clientGUI::sendConnectInfo(QString _t1, int _t2, QString _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void clientGUI::sendMsg(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void clientGUI::quitClient()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void clientGUI::updateStatus(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void clientGUI::chatPageBuilt()
{
    QMetaObject::activate(this, &staticMetaObject, 4, 0);
}
QT_END_MOC_NAMESPACE
